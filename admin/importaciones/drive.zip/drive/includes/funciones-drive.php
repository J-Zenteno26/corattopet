<?php

declare(strict_types=1);

const DRIVE_FOLDER_MIME_TYPE = 'application/vnd.google-apps.folder';
const DRIVE_API_BASE_URL = 'https://www.googleapis.com/drive/v3';

final class DriveImportException extends RuntimeException
{
    public function __construct(public readonly string $errorType, string $message)
    {
        parent::__construct($message);
    }
}

function idCarpetaDriveValido(mixed $value): ?string
{
    if (!is_string($value)) {
        return null;
    }
    $value = trim($value);

    return $value === 'root' || preg_match('/^[A-Za-z0-9_-]{10,200}$/', $value) === 1 ? $value : null;
}

function tokenTemporalDriveValido(mixed $value): ?string
{
    if (!is_string($value)) {
        return null;
    }
    $value = trim($value);

    return strlen($value) >= 20
        && strlen($value) <= 4096
        && preg_match('/[\s\x00-\x1F\x7F]/', $value) !== 1
            ? $value
            : null;
}

function construirQueryDrive(array $parameters): string
{
    return http_build_query($parameters, '', '&', PHP_QUERY_RFC3986);
}

function solicitarDrive(string $path, string $accessToken, array $parameters): array
{
    $url = DRIVE_API_BASE_URL . '/' . ltrim($path, '/');
    $query = construirQueryDrive($parameters);
    if ($query !== '') {
        $url .= '?' . $query;
    }

    $handle = curl_init($url);
    if ($handle === false) {
        throw new DriveImportException('unavailable', 'Drive API no está disponible en este momento.');
    }
    curl_setopt_array($handle, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTPHEADER => [
            'Accept: application/json',
            'Authorization: Bearer ' . $accessToken,
        ],
    ]);
    $body = curl_exec($handle);
    $status = (int) curl_getinfo($handle, CURLINFO_RESPONSE_CODE);
    $failed = $body === false;
    curl_close($handle);

    if ($failed || $status === 0) {
        throw new DriveImportException('unavailable', 'Drive API no respondió. Intenta nuevamente.');
    }

    $decoded = json_decode((string) $body, true);
    if ($status < 200 || $status >= 300) {
        throw normalizarErrorDrive($status, is_array($decoded) ? $decoded : []);
    }
    if (!is_array($decoded)) {
        throw new DriveImportException('unavailable', 'Drive API devolvió una respuesta no válida.');
    }

    return $decoded;
}

function normalizarErrorDrive(int $status, array $payload): DriveImportException
{
    $googleStatus = strtoupper((string) ($payload['error']['status'] ?? ''));
    if ($status === 401 || $googleStatus === 'UNAUTHENTICATED') {
        return new DriveImportException('expired_token', 'La autorización de Google venció. Autoriza nuevamente.');
    }
    if ($status === 403 || $googleStatus === 'PERMISSION_DENIED') {
        return new DriveImportException('access_denied', 'Google Drive denegó el acceso a la carpeta seleccionada.');
    }
    if ($status === 404 || $googleStatus === 'NOT_FOUND') {
        return new DriveImportException('invalid_folder', 'La carpeta seleccionada no existe o ya no está disponible.');
    }

    return new DriveImportException('google_error', 'Google Drive no pudo completar la solicitud. Intenta nuevamente.');
}

function obtenerCarpetaDrive(string $folderId, string $accessToken): array
{
    $folder = solicitarDrive(
        'files/' . rawurlencode($folderId),
        $accessToken,
        ['supportsAllDrives' => 'true', 'fields' => 'id,name,mimeType']
    );
    if (($folder['mimeType'] ?? null) !== DRIVE_FOLDER_MIME_TYPE) {
        throw new DriveImportException('invalid_folder', 'El elemento seleccionado no es una carpeta de Drive.');
    }

    return [
        'id' => (string) ($folder['id'] ?? $folderId),
        'nombre' => (string) ($folder['name'] ?? 'Carpeta sin nombre'),
        'mime_type' => DRIVE_FOLDER_MIME_TYPE,
    ];
}

function listarHijosDirectosDrive(string $folderId, string $accessToken, ?callable $requester = null): array
{
    $items = [];
    $pageToken = null;
    $request = $requester ?? 'solicitarDrive';
    do {
        $parameters = [
            'q' => sprintf("'%s' in parents and trashed = false", $folderId),
            'pageSize' => '1000',
            'supportsAllDrives' => 'true',
            'includeItemsFromAllDrives' => 'true',
            'fields' => 'nextPageToken,files(id,name,mimeType,size,fileExtension)',
        ];
        if ($pageToken !== null) {
            $parameters['pageToken'] = $pageToken;
        }
        $response = $request('files', $accessToken, $parameters);
        foreach (is_array($response['files'] ?? null) ? $response['files'] : [] as $item) {
            if (!is_array($item)) {
                continue;
            }
            $mimeType = (string) ($item['mimeType'] ?? 'application/octet-stream');
            $name = (string) ($item['name'] ?? 'Elemento sin nombre');
            $extension = extensionNormalizadaDrive($item['fileExtension'] ?? null, $name);
            $items[] = [
                'id' => (string) ($item['id'] ?? ''),
                'nombre' => $name,
                'mime_type' => $mimeType,
                'tipo' => $mimeType === DRIVE_FOLDER_MIME_TYPE ? 'Carpeta' : 'Archivo',
                'tamano' => isset($item['size']) && is_numeric($item['size']) ? (int) $item['size'] : null,
                'extension' => $extension,
                'clasificacion' => clasificarElementoDrive($extension, $mimeType),
            ];
        }
        $next = $response['nextPageToken'] ?? null;
        $pageToken = is_string($next) && $next !== '' ? $next : null;
    } while ($pageToken !== null);

    usort($items, static fn (array $left, array $right): int => strnatcasecmp($left['nombre'], $right['nombre']));

    return $items;
}

function extensionNormalizadaDrive(mixed $fileExtension, string $name): string
{
    $extension = is_string($fileExtension) ? trim($fileExtension) : '';
    if ($extension === '') {
        $extension = (string) pathinfo($name, PATHINFO_EXTENSION);
    }

    return strtolower(ltrim($extension, '.'));
}

function clasificarElementoDrive(string $extension, string $mimeType): string
{
    $extension = strtolower($extension);
    $mimeType = strtolower(trim($mimeType));
    if (in_array($extension, ['heic', 'heif'], true) || in_array($mimeType, ['image/heic', 'image/heif'], true)) {
        return 'heic';
    }
    if (in_array($extension, ['jpg', 'jpeg', 'png', 'webp'], true)
        || in_array($mimeType, ['image/jpeg', 'image/png', 'image/webp'], true)) {
        return 'compatible';
    }

    return 'no compatible';
}

function diagnosticarSoporteHeic(): array
{
    $diagnosis = [
        'imagick_instalado' => extension_loaded('imagick') && class_exists('Imagick'),
        'heic_lectura_disponible' => false,
        'webp_escritura_disponible' => false,
    ];
    if (!$diagnosis['imagick_instalado']) {
        return $diagnosis;
    }
    try {
        $diagnosis['heic_lectura_disponible'] = Imagick::queryFormats('HEIC*') !== []
            || Imagick::queryFormats('HEIF*') !== [];
        $diagnosis['webp_escritura_disponible'] = Imagick::queryFormats('WEBP*') !== [];
    } catch (Throwable) {
        // El diagnóstico es informativo y nunca debe detener el análisis de Drive.
    }

    return $diagnosis;
}
