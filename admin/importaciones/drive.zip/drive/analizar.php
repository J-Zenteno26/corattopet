<?php

declare(strict_types=1);

require_once dirname(__DIR__, 3) . '/config/app.php';
require_once dirname(__DIR__, 3) . '/shared/seguridad.php';
require_once __DIR__ . '/includes/funciones-drive.php';

header('Content-Type: application/json; charset=UTF-8');
header('Cache-Control: no-store');

function responderAnalisisDrive(int $status, array $payload): never
{
    http_response_code($status);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR);
    exit;
}

requireAuthentication();

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header('Allow: POST');
    responderAnalisisDrive(405, ['ok' => false, 'message' => 'Método no permitido.']);
}
if (!validateCsrfToken($_POST['csrf_token'] ?? null)) {
    responderAnalisisDrive(403, ['ok' => false, 'message' => 'La solicitud no es válida. Recarga la página.']);
}

$folderId = idCarpetaDriveValido($_POST['folder_id'] ?? null);
$accessToken = tokenTemporalDriveValido($_POST['access_token'] ?? null);
if ($folderId === null) {
    responderAnalisisDrive(422, ['ok' => false, 'message' => 'La carpeta seleccionada no es válida.']);
}
if ($accessToken === null) {
    responderAnalisisDrive(401, ['ok' => false, 'message' => 'La autorización de Google no es válida o venció.']);
}

try {
    $folder = obtenerCarpetaDrive($folderId, $accessToken);
    $items = listarHijosDirectosDrive($folderId, $accessToken);
    $folderCount = count(array_filter($items, static fn (array $item): bool => $item['tipo'] === 'Carpeta'));
    $heicDiagnosis = diagnosticarSoporteHeic();
    $hasHeic = count(array_filter($items, static fn (array $item): bool => $item['clasificacion'] === 'heic')) > 0;
    $canConvertHeic = $heicDiagnosis['imagick_instalado']
        && $heicDiagnosis['heic_lectura_disponible']
        && $heicDiagnosis['webp_escritura_disponible'];
    responderAnalisisDrive(200, [
        'ok' => true,
        'message' => $items === [] ? 'La carpeta no contiene elementos directos.' : 'Carpeta analizada correctamente.',
        'carpeta' => $folder,
        'cantidad_elementos' => count($items),
        'cantidad_subcarpetas' => $folderCount,
        'cantidad_archivos' => count($items) - $folderCount,
        'elementos' => $items,
        'diagnostico_heic' => $heicDiagnosis,
        'advertencia_heic' => $hasHeic && !$canConvertHeic
            ? 'HEIC detectado, pero este servidor todavía no dispone del conversor requerido.'
            : null,
    ]);
} catch (DriveImportException $exception) {
    $status = match ($exception->errorType) {
        'expired_token' => 401,
        'access_denied' => 403,
        'invalid_folder' => 422,
        default => 502,
    };
    responderAnalisisDrive($status, ['ok' => false, 'message' => $exception->getMessage()]);
} catch (Throwable) {
    responderAnalisisDrive(500, ['ok' => false, 'message' => 'No fue posible analizar la carpeta. Intenta nuevamente.']);
}
